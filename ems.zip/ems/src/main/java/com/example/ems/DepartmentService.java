package com.example.ems;

public class DepartmentService {

}
